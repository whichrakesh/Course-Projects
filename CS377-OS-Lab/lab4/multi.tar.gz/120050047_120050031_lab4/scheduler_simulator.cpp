#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include "event_manager.h"

using namespace std;

event_mgnr em;
int current_time = 0;
bool DEBUG = false;

struct scheduling_level {
	int level_no;
	int priority;
	int time_slice;	//either some integer or N
};

struct scheduler {
	int no_of_levels;
	vector<scheduling_level> levels_arr;
};

struct process_phase {
	int itrs;	//number of iterations
	int cpu_b;	//cpu burst time
	int io_b;	//IO burst time
};

enum State {
	BLOCKED, RUNNING, READY, NOT_STARTED, TERMINATED
};

struct process {
	int pid;
	int start_priority;
	int admission;
	State state;
	int current_phase; //current phase
	int current_iteration; //current iteration in a phase
	int cpu_time_completed; // cpu time completed for the current iteration
	int current_start_time;
	vector<process_phase> phases;
	int checkTerminated(){
		return current_phase == phases.size();
	}
	void incrementPhaseCount(){
        this->current_iteration++;
        if(this->current_iteration == this->phases[current_phase].itrs){
            this->current_iteration = 0;
            this->current_phase++;
            if(this->current_phase == this->phases.size()){
                this->state = TERMINATED;
                cout << "PID :: " << pid << "  TIME :: " << current_time << "  EVENT :: Process terminated\n";
            }
        }
	}
	void start(){
        if(DEBUG)
            cout << current_time << ": process " << this->pid << " started\n";
        current_phase = 0;
        current_iteration = 0;
        cpu_time_completed = 0;
        state = READY;
	}
	int getNextIO(){
        return current_time + phases[current_phase].cpu_b - cpu_time_completed;
	}
    void admitProcess(){
        if(DEBUG)
            cout << current_time << ": process " << this->pid << " admitted\n";
        cout << "PID :: " << pid << "  TIME :: " << current_time << "  EVENT :: Process Admitted\n";
        this->start();
    }
    void startIO(){
        if(DEBUG)
            cout << current_time << ": process " << this->pid << " IO started\n";
        cout << "PID :: " << pid << "  TIME :: " << current_time << "  EVENT :: IO started\n";
        this->state = BLOCKED;
        em.add_event(current_time + phases[current_phase].io_b, IO_END, this->pid);
    }
    void endIO(){
        if(DEBUG)
            cout << current_time << ": process " << this->pid << " IO ended\n";
        cout << "PID :: " << pid << "  TIME :: " << current_time << "  EVENT :: IO burst completed\n";
        this->state = READY;
        cpu_time_completed = 0;
        this->incrementPhaseCount();
    }
    void preempt(){
        if(DEBUG)
            cout << current_time << ": process " << this->pid << " preempted\n";
        cout << "PID :: " << pid << "  TIME :: " << current_time << "  EVENT :: Process pre-empted\n";
        this->state = READY;
        cpu_time_completed += current_time - current_start_time;
    }
    void dispatch(int &next_io_t){
        if(DEBUG)
            cout << current_time << ": process " << this->pid << " dispatched\n";
        cout << "PID :: " << pid << "  TIME :: " << current_time << "  EVENT :: CPU started\n";
        this->state = RUNNING;
        this->current_start_time = current_time;
        next_io_t = getNextIO();
    }
};

scheduler Scheduler;
vector<process> p_list;

process* getProcessByPID(int Pid){
    int i = 0;
    for(; i < p_list.size(); i++){
        if(p_list[i].pid == Pid)
            return &p_list[i];
    }
}
void handling_PROCESS_SPEC_file(){
	string line, line2;
	int pid, prior;
	int adm;
	int iter;
	int cpu_t, io_t;
	ifstream infile("/home/suman/bin/CS377-OS-Lab/lab4_multi/120050047_120050031_lab4/test_cases/4/PROCESS_SPEC");
	while (std::getline(infile, line))
	{
		if(line=="PROCESS"){
			process proc;
			getline(infile, line2);
			std::istringstream iss(line2);
		        if (!(iss >> pid >> prior >> adm)) { break; } // error

			proc.pid = pid;
			proc.start_priority = prior;
			proc.admission = adm;
            proc.state = NOT_STARTED;
			getline(infile, line2);
			while(line2 != "END"){
				std::istringstream iss(line2);
				process_phase pp;
			        if (!(iss >> iter >> cpu_t >> io_t)) { break; } // error

				pp.itrs = iter;
			    	pp.cpu_b = cpu_t;
			    	pp.io_b = io_t;
			    	(proc.phases).push_back(pp);
			    	getline(infile, line2);
			}
			p_list.push_back(proc);
			em.add_event(proc.admission,PROCESS_ADMISSION,proc.pid);	//event type "1" represents "process admission event"

		}
	}
}

int string_to_integer(string str){
	int r=1,s=0,l=str.length(),i;
	for(i=l-1;i>=0;i--)
	{
		s = s + ((str[i] - '0')*r);
		r *= 10;
	}
	return s;
}

void handling_SCHEDULER_SPEC_file(){
	string line, line2;
	int level_count;
	int prior;
	int s_lvl;
	int t_slice;
	string t_slice1;
	ifstream infile("SCHEDULER_SPEC");
	while (std::getline(infile, line))
	{
		if(line=="SCHEDULER"){
			getline(infile, line2);
			std::istringstream iss(line2);
		    if (!(iss >> level_count)) { break; } // error

			Scheduler.no_of_levels = level_count;
			for(int i=0; i<level_count; i++){
				getline(infile, line2);
				std::istringstream iss(line2);
				if (!(iss >> s_lvl >> prior >> t_slice1)) { break; } // error
				scheduling_level scl;
				if(t_slice1 == "N")
					t_slice = 9999;
				else
					t_slice = string_to_integer(t_slice1);
				scl.level_no = s_lvl;
				scl.priority = prior;
				scl.time_slice = t_slice;

				Scheduler.levels_arr.push_back(scl);
			}
		}
	}
}

// int main()
// {

// 	handling_PROCESS_SPEC_file();
// 	handling_SCHEDULER_SPEC_file();
// 	//processing events
// 	event next;
// 	next = em.next_event();
// 	switch(next.type)
// 	{
// 		//routine for handling process admission event
// 		case 1:
// 			break;
// 		//Define routines for other required events here.

// 	}

// 	return 0;
// }
