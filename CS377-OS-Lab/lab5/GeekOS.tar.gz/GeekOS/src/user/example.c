#include <conio.h> //This is not C/C++ header file, this is in GeekOS
#include <sched.h>
int main()
{
Print("Hello World !!!"); //In conio.h Print function is there.(which is similar to printf in C)
return 0;
}
